//
//  ay_test_sdk.h
//  ay-test-sdk
//
//  Created by Amit Yadav on 03/05/22.
//

#import <Foundation/Foundation.h>

//! Project version number for ay_test_sdk.
FOUNDATION_EXPORT double ay_test_sdkVersionNumber;

//! Project version string for ay_test_sdk.
FOUNDATION_EXPORT const unsigned char ay_test_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ay_test_sdk/PublicHeader.h>


